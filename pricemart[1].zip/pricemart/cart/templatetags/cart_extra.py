# templatetags/cart_extras.py
from django import template

register = template.Library()

@register.filter
def apply_discount(total, discount_percentage):
    discount_amount = (total * discount_percentage) / 100
    discounted_total = total - discount_amount
    return discounted_total