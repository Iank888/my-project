from django.db import models
from django.contrib.auth.models import User
from products.models import product_list
class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    product_list = models.ManyToManyField(product_list, through='CartItem')

class CartItem(models.Model):
    product_list = models.ForeignKey(product_list, on_delete=models.CASCADE)
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

class PromoCode(models.Model):
    code = models.CharField(max_length=20, unique=True)
    discount_percentage = models.PositiveIntegerField()
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.code
