from django.urls import path
from .views import cart_view, add_to_cart, remove_from_cart, clear_cart, apply_promo_code, checkout,submit_pesapal_order

app_name = 'cart'

urlpatterns = [
    path('cart', cart_view, name='cart_view'),
    path('add/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('remove/<int:product_id>/', remove_from_cart, name='remove_from_cart'),
    path('promo/', apply_promo_code, name="apply_promo_code"),
    path('clear/', clear_cart, name='clear_cart'),  # Added a trailing slash for consistency
    path('checkout/', checkout, name='checkout'),
    path('submit_pesapal_order/', submit_pesapal_order, name='submit_pesapal_order'),
]