from django.shortcuts import render, redirect
from django.http import JsonResponse
from products.models import product_list
from .models import Cart, CartItem,PromoCode
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render, redirect
import requests
import json
import pesapal
@login_required

def submit_pesapal_order(request):
    # Retrieve necessary details from your Django models or form inputs
    order_id = request.POST.get("order_id")  # Replace with the actual field name from your form
    currency = "UGX"
    cart = Cart.objects.get(user=request.user)
    total_amount = cart.get_total()

    # Check if a promo code discount is applied
    promo_discount = request.session.get('promo_discount', 0)
    discounted_amount = total_amount - (total_amount * promo_discount / 100)

    # Use the discounted amount in the Pesapal payload
    amount = discounted_amount
    description = request.POST.get("description")  # Replace with the actual field name from your form
    callback_url = "https://www.yourwebsite.com/callback"

    # You should have registered your IPN URL and obtained the notification_id beforehand
    notification_id = "your_notification_id"

    # Retrieve billing address details from the form
    email_address = request.POST.get("email_address")  # Replace with the actual field name from your form
    phone_number = request.POST.get("phone_number")  # Replace with the actual field name from your form
    first_name = request.POST.get("first_name")  # Replace with the actual field name from your form
    middle_name = request.POST.get("middle_name")  # Replace with the actual field name from your form
    last_name = request.POST.get("last_name")  # Replace with the actual field name from your form
    # Add more fields as needed

    billing_address = {
        "email_address": email_address,
        "phone_number": phone_number,
        "first_name": first_name,
        "middle_name": middle_name,
        "last_name": last_name,
        # Add more fields as needed
    }

    pesapal_url = "https://cybqa.pesapal.com/pesapalv3/api/Transactions/SubmitOrderRequest"
    headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}

    payload = {
        "id": order_id,
        "currency": currency,
        "amount": amount,
        "description": description,
        "callback_url": callback_url,
        "notification_id": notification_id,
        "billing_address": billing_address
    }

    try:
        # Send the POST request to Pesapal's SubmitOrderRequest API
        response = requests.post(pesapal_url, headers=headers, data=json.dumps(payload))

        if response.status_code == 200:
            # Parse the JSON response
            pesapal_response = json.loads(response.text)

            # Extract relevant details from the response
            order_tracking_id = pesapal_response.get("order_tracking_id")
            merchant_reference = pesapal_response.get("merchant_reference")
            redirect_url = pesapal_response.get("redirect_url")

            # Store order_tracking_id and merchant_reference in your Django model if needed

            # Redirect the user to Pesapal's payment page
            return redirect(redirect_url)
        else:
            # Handle unsuccessful response
            return JsonResponse({"error": "Failed to initiate Pesapal transaction."}, status=500)
    except Exception as e:
        # Handle exceptions (e.g., network issues, timeouts)
        return JsonResponse({"error": str(e)}, status=500)


def cart_view(request):
    cart = Cart.objects.get_or_create(user=request.user)[0]
    cart_items = CartItem.objects.filter(cart=cart)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render(request, 'cart.html', {'cart_items': cart_items, 'total_price': total_price})
    
@login_required
def checkout(request):
        return render(request, 'checkout.html')

@login_required
def add_to_cart(request, product_id):
    product = product_list.objects.get(pk=product_id)
    cart = Cart.objects.get_or_create(user=request.user)[0]
    cart_item, created = CartItem.objects.get_or_create(product=product, cart=cart)
    
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    return redirect('cart_view')

@login_required
def remove_from_cart(request, product_id):
    product = Product.objects.get(pk=product_id)
    cart = Cart.objects.get(user=request.user)
    cart_item = CartItem.objects.get(product=product, cart=cart)

    if cart_item.quantity > 1:
        cart_item.quantity -= 1
        cart_item.save()
    else:
        cart_item.delete()

    return redirect('cart_view')

@login_required
def clear_cart(request):
    cart = Cart.objects.get(user=request.user)
    cart.cartitem_set.all().delete()
    return redirect('cart_view')

def apply_promo_code(request):
    if request.method == 'POST':
        promo_code = request.POST.get('promo_code')
        try:
            promo = PromoCode.objects.get(code=promo_code, active=True)
            request.session['promo_discount'] = promo.discount_percentage
            messages.success(request, f'Promo code "{promo.code}" applied successfully!')
        except PromoCode.DoesNotExist:
            messages.error(request, 'Invalid or inactive promo code.')
    return redirect('checkout')  # Adjust the redirect URL based on your project's structure
