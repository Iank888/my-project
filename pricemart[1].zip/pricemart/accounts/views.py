from django.shortcuts import render,reverse,redirect
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth import login,logout,authenticate
from forms import CustomSignUpForm
def sign_up(request):
    form = CustomSignUpForm(request.POST or None)
    context= dict()
    context["form"] = form
    if request.method == "POST":
        if form.is_valid(): 
            user=form.save()
            login(request,user)      
            return redirect(reverse('content:homepage'))
        else:
            mssg.info(request,form.errors)
            return render(request,'sign_up.html',context)
    return render(request,'sign_up.html',context)

def log_in(request):
    form = AuthenticationForm(request, data=request.POST)
    context = {'form': form}

    if request.method == "POST":
        if form.is_valid():
            username = request.POST.get('username')
            password = request.POST.get('password')
            
            # Check if the user is verified before allowing login
            user = authenticate(username=username, password=password)
            
            if user:
                if not user.is_verified:
                    messages.error(request, 'Please verify your email before logging in.')
                    return render(request, 'log_in.html', context)

                login(request, user)

                if user.is_superuser:
                    return redirect(reverse('dashboard'))
                else:
                    return redirect(reverse('content:homepage'))
            else:
                messages.error(request, 'Invalid username or password.')

    return render(request, 'log_in.html', context)
    
def log_out(request):
    logout(request)
    return redirect(reverse('accounts:log-in'))


# Create your views here.
