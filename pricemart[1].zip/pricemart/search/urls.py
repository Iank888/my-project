from django.urls import path
from .views import product_list2

urlpatterns = [
    path('search/<str:category>/', product_list2, name='product_list2'),
]