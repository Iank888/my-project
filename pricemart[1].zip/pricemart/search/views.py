# search/views.py
from django.shortcuts import render, redirect
from filtering_form import ProductFilterForm
from products.models import cate
from products.models import product_list
from forms import ProductFilterForm
def product_list2(request, category=None):
    products = product_list.objects.all()

    # Handle filtering
    form = ProductFilterForm(request.GET)
    if form.is_valid():
        if form.cleaned_data['search_query']:
            products = products.filter(name__icontains=form.cleaned_data['search_query'])
        if form.cleaned_data['min_price']:
            products = products.filter(price__gte=form.cleaned_data['min_price'])
        if form.cleaned_data['max_price']:
            products = products.filter(price__lte=form.cleaned_data['max_price'])
        if category:  # Assuming 'category' is part of the URL pattern
            products = products.filter(category=category)
    if request.method == 'POST':
        form = ProductFilterForm(request.POST)
        if form.is_valid():
            selected_category = form.cleaned_data['category']

            # Assuming you want to redirect to a new page with the selected category
            return redirect('search:product_list2', category=selected_category)

    else:
        form = ProductFilterForm()
        form.fields['category'].queryset = cate.objects.all()

    return render(request, 'product_list.html', {'form': form, 'products': products})