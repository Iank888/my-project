from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from products.models import product_list, UserProfile
from django.contrib.auth import login
from forms import SellerSignUpForm, SellerProfileForm


def homepage(request):
    return render(request, 'homepage.html')
# Create your views here.
def index(request):
    return render(request,'index.html')
   

@login_required
def product_list(request):
    products = Product.objects.all()
    return render(request, 'products/product_list.html', {'products': products})

@login_required
def product_detail(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    return render(request, 'products/product_detail.html', {'product': product})

@login_required
def seller_products(request):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    seller_products = Product.objects.filter(seller=request.user)
    return render(request, 'products/seller_products.html', {'seller_products': seller_products, 'user_profile': user_profile})

@login_required
def add_product(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        price = request.POST.get('price')

        # Create a new product for the current user (seller)
        product = Product.objects.create(name=name, price=price, seller=request.user)
        return redirect('seller_products')

    return render(request, 'products/add_product.html')

@login_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, pk=product_id)

    if request.method == 'POST':
        product.name = request.POST.get('name')
        product.price = request.POST.get('price')
        product.save()
        return redirect('seller_products')

    return render(request, 'products/edit_product.html', {'product': product})

@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    product.delete()
    return redirect('seller_products')
   
def seller_signup(request):
    if request.method == 'POST':
        form = SellerSignUpForm(request.POST)
        profile_form = SellerProfileForm(request.POST)
        if form.is_valid() and profile_form.is_valid():
            user = form.save(commit=False)
            user.save()

            profile = profile_form.save(commit=False)
            profile.user = user
            profile.is_seller = True  # Mark user as a seller
            profile.save()

            login(request, user)
            return redirect('seller_dashboard')  # Redirect to the seller's dashboard or another appropriate page
    else:
        form = SellerSignUpForm()
        profile_form = SellerProfileForm()

    return render(request, 'registration/seller_signup.html', {'form': form, 'profile_form': profile_form})
  
def seller_dashboard(request):
    # Retrieve products associated with the current seller (assuming seller is identified by the user)
    seller_products = Product.objects.filter(seller=request.user)
    return render(request, 'dashboard/seller_dashboard.html', {'seller_products': seller_products})