from django.urls import path
from .views import product_list, product_detail, seller_products, add_product, edit_product, delete_product,homepage,index,seller_dashboard,seller_signup


urlpatterns = [
    path('home/', homepage, name='homepage'),
    path('index/',index,name='index'),
    path('products/', product_list, name='product_list'),
    path('products/<int:product_id>/', product_detail, name='product_detail'),
    path('seller/products/', seller_products, name='seller_products'),
    path('seller/products/add/', add_product, name='add_product'),
    path('seller/products/<int:product_id>/edit/', edit_product, name='edit_product'),
    path('seller/products/<int:product_id>/delete/', delete_product, name='delete_product'),
    path('seller/dashboard/', seller_dashboard, name='seller_dashboard'),
    path('seller/signup/',seller_signup,name='seller_signup'),
]
