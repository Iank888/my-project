# forms.py in your app
from django import forms
from products.models import cate

class ProductFilterForm(forms.Form):
    search_query = forms.CharField(required=False)
    min_price = forms.DecimalField(required=False)
    max_price = forms.DecimalField(required=False)
    category = forms.ModelChoiceField(queryset=cate.objects.all(), required=False)