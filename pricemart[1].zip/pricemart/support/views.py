from django.shortcuts import render,reverse,redirect
from django.contrib import messages as mssg
from products.models import product_list,messages
from orders.models import orders
from forms import make_order_form,message_form
def messages(request):
    context = dict()
    form = message_form(request.POST or None)
    context['form'] = form
    if request.method == "POST":
        if form.is_valid: 
            order=form.save()
            mssg.info(request,'Thank you for filling the form. Will get back to you soon')
    return render(request,'messages.html',context)


# Create your views here.
