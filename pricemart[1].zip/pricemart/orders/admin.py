from django.contrib import admin
from .models import orders
admin.site.register(orders)

# Register your models here.
