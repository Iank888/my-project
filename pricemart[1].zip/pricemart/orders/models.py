from django.db import models
from django.contrib.auth.models import User
from products.models import product_list
# Create your models here.

class orders(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email=models.EmailField(max_length=64)
    phone = models.CharField(max_length=30)
    house_name = models.CharField(max_length=80)
    location = models.CharField(max_length=60)
    pin = models.IntegerField()
    date = models.DateTimeField(auto_now = True)
    user = models.ForeignKey(User,on_delete = models.CASCADE)
    product_list = models.ForeignKey(product_list,on_delete = models.CASCADE)
    status = models.CharField(max_length=30, default='Pending')
    order_status = models.CharField(max_length=30, default='True')

