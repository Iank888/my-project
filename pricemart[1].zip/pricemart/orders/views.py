from django.shortcuts import render, reverse, redirect
from products.models import product_list, messages
from orders.models import orders
from forms import make_order_form, message_form

def my_orders(request):
    context = dict()
    user = request.user
    myorders = orders.objects.filter(user_id=user.id).order_by('-date')
    context['orders'] = myorders
    return render(request, 'my_orders.html', context)

def cancel_order(request, id):
    order = orders.objects.get(id=id)
    order.order_status = 'Cancelled'
    order.save()
    mssg.info(request, 'Order cancelled successfully. Refund will be credited to your bank account within 3-4 working days')
    return redirect(reverse('orders:my-orders'))

def checkout(request, id):
    context = dict()
    customer = request.user
    form = make_order_form(request.POST or None)
    context['customer'] = customer
    context['form'] = form

    if request.method == "POST":
        if form.is_valid():
            order = form.save(commit=False)
            order.user_id = customer.id
            order.cake_list_id = id
            order.save()
            context['id'] = id
            return render(request, 'landingpage.html', context)

    return render(request, 'delivery_details.html', context)

def payment_cancelled(request):
    cancel_order = orders.objects.latest('id')
    if cancel_order.status == 'Pending':
        cancel_order.delete()
    return redirect(reverse('content:homepage'))

def payment_successful(request):
    success_order = orders.objects.latest('id')
    success_order.status = 'Success'
    success_order.save()
    return redirect(reverse('orders:my-orders'))