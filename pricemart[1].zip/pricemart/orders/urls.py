from django.urls import path
from .views import checkout,payment_successful,cancel_order,my_orders,payment_cancelled
urlpatterns = [
    path('myorders/', my_orders, name='my_orders'),
    path('cancelorder/', cancel_order, name='cance_lorder'),
    path('checkout/', checkout, name='checkout'),
]