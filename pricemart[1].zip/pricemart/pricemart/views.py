from django.shortcuts import render,redirect,reverse,get_object_or_404
from django.contrib.auth.models import User
from products.models import messages,product_list
from orders.models import orders
from forms import add_product_form



# Create your views here.

def dashboard(request):
    context = dict()
    context['orders'] = orders.objects.all().order_by('-date')
    context['messages'] = messages.objects.all().order_by('-date')
    return render(request,'admin/dashboard.html',context)

def default_admin_view(request):
    return redirect('dashboard_view')
    
def update_profile(request):
    context = dict()
    admin_user = User.objects.get(is_superuser = True )
    context['user'] = admin_user
    if request.method == "POST":
        first_name = request.POST.get('first_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        admin_user.username = username
        admin_user.first_name = first_name
        admin_user.email = email
        admin_user.save()
        return redirect(reverse('update-profile'))
    return render(request,'admin/update_profile.html',context)

def user_list(request):
    context = dict()
    user = User.objects.filter(is_superuser = False )
    context['users'] = user
    return render(request,'admin/user_list.html',context)
def add_product(request):
    context = dict()
    form = add_product_form()
    lists = product_list.objects.all()
    context['form'] = form
    context['lists'] = lists
    if request.method == 'POST':
        form = add_product_form(request.POST,request.FILES)   
        if form.is_valid():
            form.save() 
            messages.info(request,'Product added successfully')
    return render(request,'admin/add_view_products.html',context)

def update_product(request,id):
    context = dict()
    form = add_product_form()
    item=product_list.objects.get(id=id)
    context['form'] = form
    context['item'] = item
    if request.method == 'POST':  
        form = add_product_form(request.POST,request.FILES, instance = item)   
        if form.is_valid():
            form.save()
            return redirect(reverse('add-product')) 
    return render(request,'admin/update_products.html',context)

def delete_product(request,id):
    item = get_object_or_404(product_list,id=id)
    item.delete()
    messages.error(request,'Product deleted successfully')
    return redirect(reverse('add-product'))
