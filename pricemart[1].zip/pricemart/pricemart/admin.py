from django.contrib import admin
from products.models import cate,product_list,messages
from cart.models import Cart,CartItem,PromoCode
from orders.models import orders
from .views import default_admin_view
class CustomAdminSite(admin.AdminSite):
    site_header = 'Custom Admin Dashboard'

admin_site = CustomAdminSite(name='custom_admin')

admin_site.register(product_list)

admin_site.register(cate)
admin_site.register(messages)
admin_site.register(orders)

admin_site.register(Cart)

admin_site.register(CartItem)
 

admin_site.register(PromoCode)
