# admin/apps.py
from django.contrib.admin.apps import AdminConfig

class AdminConfig(AdminConfig):
    pass
