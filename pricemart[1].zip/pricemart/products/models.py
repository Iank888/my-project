from django.db import models

# Create your models here.
from django.contrib.auth.models import User
categories = [
    ('Select Category','Select Category'),
    ('Phones','Phones'),
    ('Electronics','Electronics'),
    ('Fashion','Fashion'),
    ('Computers','Computers'),
    ('Beauty &Cosmetics','Beauty &Cosmetics'),
    ('Kicthen Items','Kicthen Items'),
    ('Cakes','Cakes'),
]
class cate(models.Model):
    category = models.CharField(max_length=50, choices=categories)
class product_list(models.Model):
    name = models.CharField(max_length=30)
    category = models.CharField(max_length=30, choices = categories , default = 'Select Category')
    description = models.CharField( max_length=300)
    price = models.IntegerField(blank=True, null=True)
    image = models.ImageField(upload_to='images/')
    seller = models.ForeignKey(User, on_delete=models.CASCADE)

    
class messages(models.Model):
    name = models.CharField(max_length=30)
    email=models.EmailField(max_length=64)
    message = models.CharField( max_length=250)
    date = models.DateTimeField(auto_now = True)
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_seller = models.BooleanField(default=False)
