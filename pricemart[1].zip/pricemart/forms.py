from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User  # Added import for User model
from products.models import product_list, messages
from orders.models import orders
from products.models import cate
from django.contrib.auth.models import User
from products.models import UserProfile


class add_product_form(forms.ModelForm):
    class Meta:
        model = product_list
        fields = ['name', 'category', 'description', 'price', 'image']

class make_order_form(forms.ModelForm):
    class Meta:
        model = orders
        fields = ['first_name', 'last_name', 'email', 'phone', 'house_name', 'pin', 'location']

class message_form(forms.ModelForm):
    class Meta:
        model = messages
        fields = '__all__'

class ProductFilterForm(forms.Form):
    search_query = forms.CharField(required=False)
    min_price = forms.DecimalField(required=False)
    max_price = forms.DecimalField(required=False)
    category = forms.ModelChoiceField(queryset=cate.objects.all(), required=False)

class CustomSignUpForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=True, help_text='Required.')
    last_name = forms.CharField(max_length=30, required=True, help_text='Required.')
    email = forms.EmailField(max_length=254, help_text='Required. Enter a valid email address.')

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username', 'email', 'password1', 'password2']
     
class SellerSignUpForm(UserCreationForm):
    email = forms.EmailField(max_length=200, help_text='Required. Enter a valid email address.')

class SellerProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['is_seller']